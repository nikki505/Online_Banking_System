import { BrowserRouter, Routes, Route, Link, useNavigate } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Accounts from './pages/Accounts';
import Transfers from './pages/Transfers';
import Transactions from './pages/Transactions';
import ScheduledTransfersPage from './pages/ScheduledTransfers';
import { useState } from 'react';
import { setAccessToken } from './api/client';

function Nav() {
  const nav = useNavigate();
  const me = JSON.parse(localStorage.getItem('me') || 'null');
  const logout = () => { localStorage.removeItem('me'); setAccessToken(null); nav('/login'); };
  return (
    <nav style={{ display:'flex', gap:12, padding:12, borderBottom:'1px solid #ddd' }}>
      <Link to="/">Dashboard</Link>
      <Link to="/accounts">Accounts</Link>
      <Link to="/transfers">Transfers</Link>
      <Link to="/transactions">Transactions</Link>
      <Link to="/scheduled">Scheduled</Link>
      <div style={{ marginLeft:'auto' }}>
        {me ? (<><span>{me.email}</span> <button onClick={logout} style={{ marginLeft:8 }}>Logout</button></>) : <Link to="/login">Login</Link>}
      </div>
    </nav>
  );
}

function Protected({ children }) {
  const me = JSON.parse(localStorage.getItem('me') || 'null');
  if (!me) return <Login />;
  return children;
}

export default function App() {
  return (
    <BrowserRouter>
      <Nav />
      <Routes>
        <Route path="/" element={<Protected><Dashboard/></Protected>} />
        <Route path="/accounts" element={<Protected><Accounts/></Protected>} />
        <Route path="/transfers" element={<Protected><Transfers/></Protected>} />
        <Route path="/transactions" element={<Protected><Transactions/></Protected>} />
        <Route path="/scheduled" element={<Protected><ScheduledTransfersPage/></Protected>} />
        <Route path="/login" element={<Login/>} />
        <Route path="/register" element={<Register/>} />
      </Routes>
    </BrowserRouter>
  );
}
