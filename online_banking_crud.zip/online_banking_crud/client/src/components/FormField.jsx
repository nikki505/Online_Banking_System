export default function FormField({ label, ...props }) {
  return (
    <label style={{ display:'block', margin:'8px 0' }}>
      <div style={{ fontSize:12, opacity:0.7 }}>{label}</div>
      <input {...props} style={{ padding:8, width:'100%' }} />
    </label>
  );
}
