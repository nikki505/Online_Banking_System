export default function Modal({ title, open, onClose, children }) {
  if (!open) return null;
  return (
    <div style={{ position:'fixed', inset:0, background:'#0003', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div style={{ background:'#fff', padding:20, width:500, maxWidth:'95%', borderRadius:8 }}>
        <div style={{ display:'flex', justifyContent:'space-between', marginBottom:10 }}>
          <h3 style={{ margin:0 }}>{title}</h3>
          <button onClick={onClose}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}
