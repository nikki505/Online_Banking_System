export default function Table({ cols, rows, onEdit, onDelete }) {
  return (
    <table border="1" cellPadding="8" style={{ width:'100%', borderCollapse:'collapse' }}>
      <thead><tr>{cols.map(c => <th key={c.key}>{c.label}</th>)}<th>Actions</th></tr></thead>
      <tbody>
        {rows.map(r => (
          <tr key={r._id}>
            {cols.map(c => <td key={c.key}>{c.render ? c.render(r[c.key], r) : r[c.key]}</td>)}
            <td>
              <button onClick={()=>onEdit(r)}>Edit</button>
              <button onClick={()=>onDelete(r)} style={{ marginLeft:8 }}>Delete</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
