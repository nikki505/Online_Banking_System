import { useState } from 'react';
import api from '../api/client';
import { useNavigate, Link } from 'react-router-dom';
import { setAccessToken } from '../api/client';

export default function Login() {
  const [form, setForm] = useState({ email:'', password:'' });
  const [err, setErr] = useState(null);
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault(); setErr(null);
    try {
      const { data } = await api.post('/auth/login', form);
      setAccessToken(data.accessToken);
      localStorage.setItem('me', JSON.stringify(data.user));
      nav('/');
    } catch (e) {
      setErr(e.response?.data?.error || 'Login failed');
    }
  };

  return (
    <div style={{ maxWidth:420, margin:'40px auto' }}>
      <h2>Login</h2>
      <form onSubmit={submit}>
        <input placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} />
        <input placeholder="Password" value={form.password} type="password" onChange={e=>setForm({...form, password:e.target.value})} />
        <button type="submit">Login</button>
      </form>
      {err && <p style={{ color:'red' }}>{String(err)}</p>}
      <p>No account? <Link to="/register">Register</Link></p>
    </div>
  );
}
