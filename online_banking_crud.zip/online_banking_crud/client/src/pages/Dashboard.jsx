export default function Dashboard(){
  return (<div style={{ maxWidth:900, margin:'20px auto' }}>
    <h2>Dashboard</h2>
    <p>Use the navigation to manage accounts, transfers, scheduled transfers and view transactions/summary.</p>
  </div>);
}

