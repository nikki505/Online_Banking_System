import { useEffect, useState } from 'react';
import api from '../api';
import Table from '../components/Table';
import Modal from '../components/Modal';
import FormField from '../components/FormField';

export default function Payees(){
  const [rows,setRows]=useState([]); const [open,setOpen]=useState(false); const [editing,setEditing]=useState(null);
  const [form,setForm]=useState({ name:'', accountNumber:'', bank:'Internal', nickname:'' });
  const cols=[{key:'name',label:'Name'},{key:'nickname',label:'Nickname'},{key:'accountNumber',label:'Account #'}, {key:'bank',label:'Bank'}];
  const load = async ()=>{ const {data}=await api.get('/payees'); setRows(data.items); };
  useEffect(()=>{ load(); },[]);
  const onCreate=()=>{ setEditing(null); setForm({ name:'', accountNumber:'', bank:'Internal', nickname:'' }); setOpen(true); };
  const onEdit=(r)=>{ setEditing(r); setForm({ name:r.name, accountNumber:r.accountNumber, bank:r.bank||'Internal', nickname:r.nickname||'' }); setOpen(true); };
  const onDelete=async (r)=>{ await api.delete(`/payees/${r._id}`); load(); };
  const submit=async (e)=>{ e.preventDefault();
    if(editing) await api.patch(`/payees/${editing._id}`, form);
    else await api.post('/payees', form);
    setOpen(false); load();
  };
  return (
    <div style={{ maxWidth:900, margin:'20px auto' }}>
      <h2>Payees</h2>
      <button onClick={onCreate}>+ New Payee</button>
      <div style={{ marginTop:12 }}>
        <Table cols={cols} rows={rows} onEdit={onEdit} onDelete={onDelete}/>
      </div>
      <Modal title={editing?'Edit Payee':'New Payee'} open={open} onClose={()=>setOpen(false)}>
        <form onSubmit={submit}>
          <FormField label="Name" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))}/>
          <FormField label="Nickname" value={form.nickname} onChange={e=>setForm(f=>({...f,nickname:e.target.value}))}/>
          <FormField label="Account Number" value={form.accountNumber} onChange={e=>setForm(f=>({...f,accountNumber:e.target.value}))}/>
          <FormField label="Bank" value={form.bank} onChange={e=>setForm(f=>({...f,bank:e.target.value}))}/>
          <button type="submit">{editing?'Save':'Create'}</button>
        </form>
      </Modal>
    </div>
  );
}
