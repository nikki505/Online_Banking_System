import { useState } from 'react';
import api from '../api/client';
import { useNavigate, Link } from 'react-router-dom';
import { setAccessToken } from '../api/client';

export default function Register() {
  const [form, setForm] = useState({ email:'', password:'' });
  const [err, setErr] = useState(null);
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault(); setErr(null);
    try {
      const { data } = await api.post('/auth/register', form);
      setAccessToken(data.accessToken);
      localStorage.setItem('me', JSON.stringify(data.user));
      nav('/');
    } catch (e) {
      setErr(e.response?.data?.error || 'Register failed');
    }
  };

  return (
    <div style={{ maxWidth:420, margin:'40px auto' }}>
      <h2>Register</h2>
      <form onSubmit={submit}>
        <input placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/>
        <input placeholder="Password" value={form.password} type="password" onChange={e=>setForm({...form,password:e.target.value})}/>
        <button type="submit">Create account</button>
      </form>
      {err && <p style={{ color:'red' }}>{String(err)}</p>}
      <p>Have an account? <Link to="/login">Login</Link></p>
    </div>
  );
}
