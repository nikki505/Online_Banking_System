import { useEffect, useState } from 'react';
import api from '../api/client';

export default function Accounts(){
  const [accounts, setAccounts] = useState([]);
  const [form, setForm] = useState({ type:'checking', number:'', balanceCents:0 });
  const [editing, setEditing] = useState(null);

  const load = async () => {
    const { data } = await api.get('/accounts');
    setAccounts(data.accounts);
  };
  useEffect(()=>{ load(); },[]);

  const save = async (e) => {
    e && e.preventDefault();
    if (editing) {
      await api.patch(`/accounts/${editing._id}`, form);
    } else {
      await api.post('/accounts', form);
    }
    setForm({ type:'checking', number:'', balanceCents:0 });
    setEditing(null);
    await load();
  };

  const edit = (a) => { setEditing(a); setForm({ type:a.type, number:a.number, balanceCents:a.balanceCents }); };

  const del = async (a) => { await api.delete(`/accounts/${a._id}`); await load(); };

  return (
    <div style={{ maxWidth:900, margin:'20px auto' }}>
      <h2>Accounts</h2>
      <form onSubmit={save} style={{ marginBottom: 12 }}>
        <select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option value="checking">Checking</option><option value="savings">Savings</option></select>
        <input placeholder="Number" value={form.number} onChange={e=>setForm({...form,number:e.target.value})} disabled={!!editing}/>
        <input placeholder="Balance in cents" value={form.balanceCents} onChange={e=>setForm({...form,balanceCents:e.target.value})}/>
        <button type="submit">{editing ? 'Save' : 'Create'}</button>
      </form>
      <table border="1" cellPadding="8"><thead><tr><th>Number</th><th>Type</th><th>Balance</th><th>Actions</th></tr></thead>
        <tbody>
          {accounts.map(a => (<tr key={a._id}><td>{a.number}</td><td>{a.type}</td><td>${(a.balanceCents/100).toFixed(2)}</td>
            <td><button onClick={()=>edit(a)}>Edit</button><button onClick={()=>del(a)} style={{ marginLeft:8 }}>Delete</button></td></tr>))}
        </tbody>
      </table>
    </div>
  );
}
