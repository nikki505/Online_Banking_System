import { useEffect, useState } from 'react';
import api from '../api/client';

export default function Transfers(){
  const [accounts, setAccounts] = useState([]);
  const [form, setForm] = useState({ fromAccount:'', toAccount:'', amount:'', memo:'', category:'Other', scheduleAt:'' });
  const [msg, setMsg] = useState(null), [err, setErr] = useState(null);

  useEffect(()=>{ api.get('/accounts').then(r=>setAccounts(r.data.accounts)); },[]);

  const submit = async (e) => {
    e.preventDefault(); setMsg(null); setErr(null);
    try {
      const body = {
        fromAccount: form.fromAccount,
        toAccount: form.toAccount,
        amountCents: Math.round(parseFloat(form.amount || 0) * 100),
        memo: form.memo,
        category: form.category,
        scheduleAt: form.scheduleAt || undefined
      };
      const path = form.scheduleAt ? '/transfers/user' : '/transfers/own';
      const { data } = await api.post(path, body);
      setMsg('Transfer created');
    } catch (e) {
      setErr(e.response?.data?.error || 'Transfer failed');
    }
  };

  return (
    <div style={{ maxWidth:520, margin:'20px auto' }}>
      <h2>Make Transfer</h2>
      <form onSubmit={submit}>
        <select value={form.fromAccount} onChange={e=>setForm(f=>({...f,fromAccount:e.target.value}))}>
          <option value="">From</option>
          {accounts.map(a=> <option key={a.number} value={a.number}>{a.number} ({a.type})</option>)}
        </select>
        <input placeholder="To account number" value={form.toAccount} onChange={e=>setForm(f=>({...f,toAccount:e.target.value}))}/>
        <input placeholder="Amount (e.g. 12.34)" value={form.amount} onChange={e=>setForm(f=>({...f,amount:e.target.value}))}/>
        <select value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))}>
          <option>Other</option><option>Food</option><option>Bills</option><option>Shopping</option><option>Transport</option><option>Entertainment</option>
        </select>
        <input placeholder="Memo" value={form.memo} onChange={e=>setForm(f=>({...f,memo:e.target.value}))}/>
        <label>Schedule (optional ISO): <input type="datetime-local" value={form.scheduleAt} onChange={e=>setForm(f=>({...f,scheduleAt:e.target.value}))}/></label>
        <button type="submit">Send</button>
      </form>
      {msg && <p style={{ color:'green' }}>{msg}</p>}
      {err && <p style={{ color:'red' }}>{String(err)}</p>}
    </div>
  );
}
