import { useEffect, useState } from 'react';
import api from '../api/client';

export default function ScheduledTransfersPage(){
  const [accounts, setAccounts] = useState([]);
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ fromAccount:'', toAccount:'', amount:'', memo:'', executeAt:'' });

  useEffect(()=>{ api.get('/accounts').then(r=>setAccounts(r.data.accounts)); load(); }, []);
  const load = async ()=> { const { data } = await api.get('/scheduled-transfers'); setList(data.scheduled); };

  const submit = async (e) => {
    e.preventDefault();
    await api.post('/scheduled-transfers', {
      fromAccount: form.fromAccount,
      toAccount: form.toAccount,
      amountCents: Math.round(parseFloat(form.amount || 0) * 100),
      memo: form.memo,
      executeAt: form.executeAt
    });
    setForm({ fromAccount:'', toAccount:'', amount:'', memo:'', executeAt:'' });
    await load();
  };

  const cancel = async (id) => { await api.delete(`/scheduled-transfers/${id}`); await load(); };

  return (
    <div style={{ maxWidth:800, margin:'20px auto' }}>
      <h2>Scheduled Transfers</h2>
      <form onSubmit={submit}>
        <select value={form.fromAccount} onChange={e=>setForm(f=>({...f,fromAccount:e.target.value}))}><option value="">From</option>{accounts.map(a=><option key={a.number} value={a.number}>{a.number}</option>)}</select>
        <input placeholder="To account number" value={form.toAccount} onChange={e=>setForm(f=>({...f,toAccount:e.target.value}))}/>
        <input placeholder="Amount" value={form.amount} onChange={e=>setForm(f=>({...f,amount:e.target.value}))}/>
        <input type="datetime-local" value={form.executeAt} onChange={e=>setForm(f=>({...f,executeAt:e.target.value}))}/>
        <input placeholder="Memo" value={form.memo} onChange={e=>setForm(f=>({...f,memo:e.target.value}))}/>
        <button type="submit">Schedule</button>
      </form>

      <h3 style={{ marginTop:20 }}>Upcoming</h3>
      <table border="1" cellPadding="6" style={{ width:'100%' }}>
        <thead><tr><th>When</th><th>From</th><th>To</th><th>Amount</th><th>Memo</th><th>Executed</th><th>Action</th></tr></thead>
        <tbody>{list.map(s => <tr key={s._id}><td>{new Date(s.executeAt).toLocaleString()}</td><td>{s.fromAccount}</td><td>{s.toAccount}</td><td>${(s.amountCents/100).toFixed(2)}</td><td>{s.memo||''}</td><td>{s.executed ? 'Yes' : 'No'}</td><td>{!s.executed && <button onClick={()=>cancel(s._id)}>Cancel</button>}</td></tr>)}</tbody>
      </table>
    </div>
  );
}
