import { useEffect, useState } from 'react';
import api from '../api/client';

export default function Transactions() {
  const [account, setAccount] = useState('');
  const [accounts, setAccounts] = useState([]);
  const [items, setItems] = useState([]);
  const [summary, setSummary] = useState([]);

  useEffect(() => {
    api.get('/accounts').then(r => {
      setAccounts(r.data.accounts);
      setAccount(r.data.accounts[0]?.number || '');
    });
  }, []);

  useEffect(() => {
    if (!account) return;

    api.get('/transactions', { params: { account } })
      .then(r => setItems(r.data.transactions));

    api.get('/transactions/summary')
      .then(r => setSummary(r.data.summary));
  }, [account]);

  return (
    <div style={{ maxWidth: 1000, margin: '20px auto' }}>
      <h2>Transactions</h2>
      <div>
        <label>
          Account
          <select value={account} onChange={e => setAccount(e.target.value)}>
            {accounts.map(a => (
              <option key={a.number} value={a.number}>
                {a.number}
              </option>
            ))}
          </select>
        </label>
      </div>
      <table border="1" cellPadding="6" style={{ marginTop: 12, width: '100%' }}>
        <thead>
          <tr>
            <th>Date</th>
            <th>From</th>
            <th>To</th>
            <th>Amount</th>
            <th>Category</th>
            <th>Status</th>
            <th>Memo</th>
          </tr>
        </thead>
        <tbody>
          {items.map(t => (
            <tr key={t._id}>
              <td>{new Date(t.createdAt).toLocaleString()}</td>
              <td>{t.fromAccount}</td>
              <td>{t.toAccount}</td>
              <td>${(t.amountCents / 100).toFixed(2)}</td>
              <td>{t.category}</td>
              <td>{t.status}</td>
              <td>{t.memo || ''}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3 style={{ marginTop: 24 }}>Spending Summary (completed)</h3>
      <table border="1" cellPadding="6">
        <thead>
          <tr>
            <th>Category</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          {summary.map(s => (
            <tr key={s.category}>
              <td>{s.category}</td>
              <td>${(s.totalCents / 100).toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

