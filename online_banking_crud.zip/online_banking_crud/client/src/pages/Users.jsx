import { useEffect, useState } from 'react';
import api from '../api';
import Table from '../components/Table';
import Modal from '../components/Modal';
import FormField from '../components/FormField';

export default function Users(){
  const [rows,setRows]=useState([]); const [open,setOpen]=useState(false); const [editing,setEditing]=useState(null);
  const [form,setForm]=useState({ role:'user' });
  const cols=[{key:'email',label:'Email'},{key:'role',label:'Role'},{key:'createdAt',label:'Created',render:v=>new Date(v).toLocaleDateString()}];
  const load=async()=>{ const {data}=await api.get('/users'); setRows(data.items); };
  useEffect(()=>{ load(); },[]);
  const onEdit=(r)=>{ setEditing(r); setForm({ role:r.role }); setOpen(true); };
  const onDelete=async (r)=>{ await api.delete(`/users/${r._id}`); load(); };
  const submit=async (e)=>{ e.preventDefault(); await api.patch(`/users/${editing._id}`, { role: form.role }); setOpen(false); load(); };

  return (
    <div style={{ maxWidth:900, margin:'20px auto' }}>
      <h2>Users (admin)</h2>
      <Table cols={cols} rows={rows} onEdit={onEdit} onDelete={onDelete}/>
      <Modal title="Edit Role" open={open} onClose={()=>setOpen(false)}>
        <form onSubmit={submit}>
          <FormField label="Role" value={form.role} onChange={e=>setForm(f=>({...f,role:e.target.value}))} list="roles"/>
          <datalist id="roles"><option value="user"/><option value="admin"/></datalist>
          <button>Save</button>
        </form>
      </Modal>
    </div>
  );
}
