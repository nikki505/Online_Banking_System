import { Router } from 'express';
import User from '../models/User.js';
import { requireAuth } from '../middleware/auth.js';
import { requireRole } from '../middleware/roles.js';

const r = Router();

r.get('/users', requireAuth, requireRole('admin'), async (req, res) => {
  const users = await User.find().select('_id email role createdAt');
  res.json({ users });
});

r.patch('/users/:id/role', requireAuth, requireRole('admin'), async (req, res) => {
  const { role } = req.body;
  if (!['user','admin'].includes(role)) return res.status(400).json({ error: 'Invalid role' });
  const u = await User.findByIdAndUpdate(req.params.id, { role }, { new: true }).select('_id email role');
  res.json({ user: u });
});

export default r;
