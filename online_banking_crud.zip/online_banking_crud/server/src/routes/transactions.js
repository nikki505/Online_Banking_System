import { Router } from 'express';
import Transaction from '../models/Transaction.js';
import { requireAuth } from '../middleware/auth.js';

const r = Router();

// GET /transactions?account=AC123&limit=50
r.get('/', requireAuth, async (req, res) => {
  const { account, limit = 100 } = req.query;
  const q = account ? { $or: [{ fromAccount: account }, { toAccount: account }], createdBy: req.user.id } : { createdBy: req.user.id };
  const items = await Transaction.find(q).sort({ createdAt: -1 }).limit(+limit);
  return res.json({ transactions: items });
});

// CREATE manual
r.post('/', requireAuth, async (req, res) => {
  const { fromAccount, toAccount, amountCents, memo, category, scheduledFor } = req.body;
  const tx = await Transaction.create({ fromAccount, toAccount, amountCents, memo, category: category || 'Other', status: scheduledFor ? 'scheduled' : 'completed', scheduledFor, createdBy: req.user.id });
  return res.status(201).json({ transaction: tx });
});

// GET summary by category
r.get('/summary', requireAuth, async (req, res) => {
  const summary = await Transaction.aggregate([
    { $match: { createdBy: req.user.id, status: 'completed' } },
    { $group: { _id: '$category', totalCents: { $sum: '$amountCents' } } },
    { $project: { category: '$_id', totalCents: 1, _id: 0 } }
  ]);
  return res.json({ summary });
});

export default r;
