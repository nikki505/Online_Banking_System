const express = require("express");
const router = express.Router();
const Account = require("../models/Account.js"); // ✅ ensure correct path
const authMiddleware = require("../middleware/auth.js"); // for protected routes

// @route   GET /api/accounts
// @desc    Get all accounts for logged-in user
// @access  Private
router.get("/", authMiddleware, async (req, res) => {
    try {
        const accounts = await Account.find({ user: req.user.id });
        res.json(accounts);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server error");
    }
});

// @route   POST /api/accounts
// @desc    Create new account
// @access  Private
router.post("/", authMiddleware, async (req, res) => {
    const { accountType, balance } = req.body;
    try {
        const newAccount = new Account({
            user: req.user.id,
            accountType,
            balance
        });
        const account = await newAccount.save();
        res.json(account);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server error");
    }
});

// @route   PUT /api/accounts/:id
// @desc    Update account
// @access  Private
router.put("/:id", authMiddleware, async (req, res) => {
    const { accountType, balance } = req.body;
    try {
        let account = await Account.findById(req.params.id);
        if (!account) return res.status(404).json({ msg: "Account not found" });

        // Ensure account belongs to user
        if (account.user.toString() !== req.user.id) {
            return res.status(401).json({ msg: "Not authorized" });
        }

        account.accountType = accountType || account.accountType;
        account.balance = balance ?? account.balance;

        await account.save();
        res.json(account);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server error");
    }
});

// @route   DELETE /api/accounts/:id
// @desc    Delete account
// @access  Private
router.delete("/:id", authMiddleware, async (req, res) => {
    try {
        let account = await Account.findById(req.params.id);
        if (!account) return res.status(404).json({ msg: "Account not found" });

        if (account.user.toString() !== req.user.id) {
            return res.status(401).json({ msg: "Not authorized" });
        }

        await account.deleteOne();
        res.json({ msg: "Account removed" });
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server error");
    }
});

module.exports = router;
