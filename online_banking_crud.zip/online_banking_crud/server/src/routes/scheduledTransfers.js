import { Router } from 'express';
import ScheduledTransfer from '../models/ScheduledTransfer.js';
import { requireAuth } from '../middleware/auth.js';

const r = Router();

// create scheduled transfer
r.post('/', requireAuth, async (req, res) => {
  const { fromAccount, toAccount, amountCents, memo, executeAt } = req.body;
  try {
    const sched = await ScheduledTransfer.create({
      userId: req.user.id, fromAccount, toAccount, amountCents, memo, executeAt: new Date(executeAt)
    });
    return res.status(201).json({ scheduled: sched });
  } catch (e) {
    return res.status(400).json({ error: e.message });
  }
});

// list
r.get('/', requireAuth, async (req, res) => {
  const items = await ScheduledTransfer.find({ userId: req.user.id }).sort({ executeAt: 1 });
  return res.json({ scheduled: items });
});

// cancel
r.delete('/:id', requireAuth, async (req, res) => {
  const s = await ScheduledTransfer.findById(req.params.id);
  if (!s || s.userId.toString() !== req.user.id) return res.status(404).json({ error: 'Not found' });
  if (s.executed) return res.status(400).json({ error: 'Already executed' });
  await s.deleteOne();
  return res.json({ ok: true });
});

export default r;
