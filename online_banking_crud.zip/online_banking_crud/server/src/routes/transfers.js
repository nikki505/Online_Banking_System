import { Router } from 'express';
import mongoose from 'mongoose';
import Account from '../models/Account.js';
import Transaction from '../models/Transaction.js';
import Audit from '../models/AuditEvent.js';
import { OwnTransferSchema, UserTransferSchema } from '../validation/transferSchemas.js';
import { transferLimiter } from '../middleware/rateLimit.js';
import { requireAuth } from '../middleware/auth.js';

const r = Router();

async function move(session, fromNum, toNum, amountCents) {
  const from = await Account.findOne({ number: fromNum }).session(session);
  const to   = await Account.findOne({ number: toNum }).session(session);
  if (!from || !to) throw new Error('Account not found');
  if (from.balanceCents < amountCents) throw new Error('Insufficient funds');

  from.balanceCents -= amountCents;
  to.balanceCents   += amountCents;

  await from.save({ session });
  await to.save({ session });
}

r.post('/own', requireAuth, transferLimiter, async (req, res) => {
  const parse = OwnTransferSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: parse.error.flatten() });
  const { fromAccount, toAccount, amountCents, memo, category } = parse.data;

  const owned = await Account.find({ userId: req.user.id, number: { $in: [fromAccount, toAccount] } });
  if (owned.length !== 2) return res.status(403).json({ error: 'Not your accounts' });

  const session = await mongoose.startSession(); session.startTransaction();
  try {
    await move(session, fromAccount, toAccount, amountCents);
    const [tx] = await Transaction.create([{
      fromAccount, toAccount, amountCents, status: 'completed', memo, category: category || 'Other', createdBy: req.user.id
    }], { session });
    await Audit.create([{ userId: req.user.id, action: 'TRANSFER_OWN', meta: { fromAccount, toAccount, amountCents } }], { session });
    await session.commitTransaction();
    res.status(201).json({ ok: true, transaction: tx });
  } catch (e) {
    await session.abortTransaction();
    res.status(400).json({ error: e.message });
  } finally {
    session.endSession();
  }
});

r.post('/user', requireAuth, transferLimiter, async (req, res) => {
  const parse = UserTransferSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: parse.error.flatten() });

  const { fromAccount, toAccount, amountCents, memo, scheduleAt, category } = parse.data;
  const from = await Account.findOne({ userId: req.user.id, number: fromAccount });
  if (!from) return res.status(403).json({ error: 'From account not yours' });

  // scheduled
  if (scheduleAt) {
    // store as Transaction (scheduled) and also ScheduledTransfer could be used; keeping Transaction with scheduledFor and status scheduled
    const tx = await Transaction.create({
      fromAccount, toAccount, amountCents, memo, status: 'scheduled', scheduledFor: new Date(scheduleAt), category: category || 'Other', createdBy: req.user.id
    });
    await Audit.create({ userId: req.user.id, action: 'TRANSFER_SCHEDULED', meta: { fromAccount, toAccount, amountCents, scheduleAt } });
    return res.status(201).json({ ok: true, transaction: tx });
  }

  // immediate
  const session = await mongoose.startSession(); session.startTransaction();
  try {
    await move(session, fromAccount, toAccount, amountCents);
    const [tx] = await Transaction.create([{
      fromAccount, toAccount, amountCents, status: 'completed', memo, category: category || 'Other', createdBy: req.user.id
    }], { session });
    await Audit.create([{ userId: req.user.id, action: 'TRANSFER_USER', meta: { fromAccount, toAccount, amountCents } }], { session });
    await session.commitTransaction();
    res.status(201).json({ ok: true, transaction: tx });
  } catch (e) {
    await session.abortTransaction();
    res.status(400).json({ error: e.message });
  } finally {
    session.endSession();
  }
});

export default r;
