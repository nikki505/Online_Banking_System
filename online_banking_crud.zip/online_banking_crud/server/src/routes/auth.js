import { Router } from 'express';
import User from '../models/User.js';
import Account from '../models/Account.js';
import Audit from '../models/AuditEvent.js';
import { hash, verify } from '../utils/hash.js';
import { signAccess, signRefresh } from '../utils/jwt.js';
import { RegisterSchema, LoginSchema } from '../validation/authSchemas.js';
import { authLimiter } from '../middleware/rateLimit.js';

const r = Router();

const generateAccountNumber = () =>
  'AC' + Math.random().toString().slice(2, 10);

r.post('/register', authLimiter, async (req, res) => {
  const parse = RegisterSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: parse.error.flatten() });

  const { email, password } = parse.data;
  const exists = await User.findOne({ email });
  if (exists) return res.status(409).json({ error: 'Email already registered' });

  const passwordHash = await hash(password);
  const user = await User.create({ email, passwordHash });

  // seed accounts for simulation
  const checking = await Account.create({
    userId: user._id, type: 'checking', number: generateAccountNumber(), balanceCents: 100000
  });
  const savings = await Account.create({
    userId: user._id, type: 'savings', number: generateAccountNumber(), balanceCents: 250000
  });

  await Audit.create({ userId: user._id, action: 'REGISTER', meta: { email } });

  const access = signAccess({ id: user._id.toString(), role: user.role });
  const refresh = signRefresh({ id: user._id.toString(), role: user.role });
  res.cookie('refreshToken', refresh, { httpOnly: true, sameSite: 'lax', secure: false, maxAge: 7*24*3600*1000 });
  return res.status(201).json({ accessToken: access, user: { id: user._id, email, role: user.role, accounts: [checking.number, savings.number] } });
});

r.post('/login', authLimiter, async (req, res) => {
  const parse = LoginSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: parse.error.flatten() });

  const { email, password } = parse.data;
  const user = await User.findOne({ email });
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await verify(user.passwordHash, password);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

  await Audit.create({ userId: user._id, action: 'LOGIN' });

  const access = signAccess({ id: user._id.toString(), role: user.role });
  const refresh = signRefresh({ id: user._id.toString(), role: user.role });
  res.cookie('refreshToken', refresh, { httpOnly: true, sameSite: 'lax', secure: false, maxAge: 7*24*3600*1000 });
  return res.json({ accessToken: access, user: { id: user._id, email: user.email, role: user.role } });
});

r.post('/logout', (req, res) => {
  res.clearCookie('refreshToken');
  return res.json({ ok: true });
});

export default r;

