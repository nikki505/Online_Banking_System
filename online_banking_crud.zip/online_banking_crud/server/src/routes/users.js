import { Router } from 'express';
import User from '../models/User.js';
import { UserPatchSchema } from '../validation/user.js';

const r = Router();

// LIST
r.get('/', async (_req,res) => {
  const items = await User.find().select('_id email role createdAt');
  res.json({ items });
});
// READ
r.get('/:id', async (req,res) => {
  const item = await User.findById(req.params.id).select('_id email role createdAt');
  if (!item) return res.status(404).json({ error: 'Not found' });
  res.json({ item });
});
// UPDATE (role)
r.patch('/:id', async (req,res) => {
  const p = UserPatchSchema.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: p.error.flatten() });
  const item = await User.findByIdAndUpdate(req.params.id, p.data, { new: true }).select('_id email role createdAt');
  if (!item) return res.status(404).json({ error: 'Not found' });
  res.json({ item });
});
// DELETE
r.delete('/:id', async (req,res) => {
  await User.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

export default r;
