const express = require("express");
const router = express.Router();
const Payee = require("../models/Payee"); // ✅ make sure path is correct
const authMiddleware = require("../middleware/auth"); // to protect routes

// @route   GET /api/payees
// @desc    Get all payees for the logged-in user
// @access  Private
router.get("/", authMiddleware, async (req, res) => {
    try {
        const payees = await Payee.find({ user: req.user.id });
        res.json(payees);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server error");
    }
});

// @route   POST /api/payees
// @desc    Add new payee
// @access  Private
router.post("/", authMiddleware, async (req, res) => {
    const { name, accountNumber, bankName } = req.body;

    try {
        const newPayee = new Payee({
            user: req.user.id,
            name,
            accountNumber,
            bankName
        });

        const payee = await newPayee.save();
        res.json(payee);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server error");
    }
});

// @route   PUT /api/payees/:id
// @desc    Update payee details
// @access  Private
router.put("/:id", authMiddleware, async (req, res) => {
    const { name, accountNumber, bankName } = req.body;

    try {
        let payee = await Payee.findById(req.params.id);
        if (!payee) return res.status(404).json({ msg: "Payee not found" });

        if (payee.user.toString() !== req.user.id) {
            return res.status(401).json({ msg: "Not authorized" });
        }

        payee.name = name || payee.name;
        payee.accountNumber = accountNumber || payee.accountNumber;
        payee.bankName = bankName || payee.bankName;

        await payee.save();
        res.json(payee);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server error");
    }
});

// @route   DELETE /api/payees/:id
// @desc    Delete payee
// @access  Private
router.delete("/:id", authMiddleware, async (req, res) => {
    try {
        let payee = await Payee.findById(req.params.id);
        if (!payee) return res.status(404).json({ msg: "Payee not found" });

        if (payee.user.toString() !== req.user.id) {
            return res.status(401).json({ msg: "Not authorized" });
        }

        await payee.deleteOne();
        res.json({ msg: "Payee removed" });
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server error");
    }
});

module.exports = router;

