import mongoose from 'mongoose';
import { config } from './config.js';

export const connectDb = async () => {
  if (!config.mongoUri) throw new Error('MONGO_URI not provided');
  await mongoose.connect(config.mongoUri, { autoIndex: true });
  console.log('MongoDB connected');
};
