import { verifyAccess, verifyRefresh, signAccess } from '../utils/jwt.js';

export const requireAuth = (req, res, next) => {
  const hdr = req.headers.authorization || '';
  const token = hdr.startsWith('Bearer ') ? hdr.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    const payload = verifyAccess(token);
    req.user = payload; // { id, role }
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid/expired token' });
  }
};

export const refreshFromCookie = (req, res) => {
  const token = req.cookies?.refreshToken;
  if (!token) return res.status(401).json({ error: 'No refresh token' });
  try {
    const p = verifyRefresh(token);
    const access = signAccess({ id: p.id, role: p.role });
    return res.json({ accessToken: access });
  } catch {
    return res.status(401).json({ error: 'Invalid refresh token' });
  }
};
