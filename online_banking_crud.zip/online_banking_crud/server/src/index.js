import express from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import cron from 'cron';
import { connectDb } from './db.js';
import { config } from './config.js';
import authRoutes from './routes/auth.js';
const accountsRoutes = require('./routes/accounts');
import transfersRoutes from './routes/transfers.js';
import transactionsRoutes from './routes/transactions.js';
import adminRoutes from './routes/admin.js';
import scheduledRoutes from './routes/scheduledTransfers.js';
import ScheduledTransfer from './models/ScheduledTransfer.js';
import Account from './models/Account.js';
import Transaction from './models/Transaction.js';

const app = express();
app.use(helmet());
app.use(morgan('dev'));
app.use(express.json());
app.use(cookieParser());
app.use(cors({ origin: config.corsOrigin, credentials: true }));

app.get('/health', (req, res) => res.json({ ok: true }));

app.use('/auth', authRoutes);
app.post('/auth/refresh', (req, res) => res.status(501).json({ error: 'Not implemented' }));

app.use('/accounts', accountsRoutes);
app.use('/transfers', transfersRoutes);
app.use('/transactions', transactionsRoutes);
app.use('/admin', adminRoutes);
app.use('/scheduled-transfers', scheduledRoutes);

connectDb().then(() => {
  app.listen(config.port, () => console.log(`API on http://localhost:${config.port}`));

  // cron job: every minute check scheduled transfers (only if enabled)
  if (config.cronEnabled) {
    // using node-cron via cron.CronJob alternative:
    const CronJob = cron.CronJob;
    const job = new CronJob('* * * * *', async () => {
      const now = new Date();
      const due = await ScheduledTransfer.find({ executed: false, executeAt: { $lte: now } });
      for (const s of due) {
        try {
          const session = await Account.startSession();
          session.startTransaction();
          try {
            const from = await Account.findOne({ number: s.fromAccount }).session(session);
            const to = await Account.findOne({ number: s.toAccount }).session(session);
            if (!from || !to) throw new Error('Account missing');
            if (from.balanceCents < s.amountCents) throw new Error('Insufficient funds');
            from.balanceCents -= s.amountCents;
            to.balanceCents += s.amountCents;
            await from.save({ session });
            await to.save({ session });
            // create transaction record (completed)
            await Transaction.create([{
              fromAccount: s.fromAccount, toAccount: s.toAccount, amountCents: s.amountCents, status: 'completed', memo: s.memo, createdBy: s.userId
            }], { session });
            s.executed = true; s.executedAt = new Date();
            await s.save({ session });
            await session.commitTransaction();
            console.log(`Executed scheduled transfer ${s._id}`);
          } catch (err) {
            await session.abortTransaction();
            console.error('Scheduled transfer failed', s._id, err.message);
          } finally {
            session.endSession();
          }
        } catch (err) {
          console.error('Error processing scheduled transfer', err.message);
        }
      }
    }, null, true, null, null, true);
    job.start();
    console.log('Scheduled transfer runner started (every minute)');
  }
});
