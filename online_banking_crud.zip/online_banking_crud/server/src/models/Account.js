import mongoose from 'mongoose';
const AccountSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true },
  type: { type: String, enum: ['checking', 'savings'], required: true },
  number: { type: String, unique: true, index: true },
  balanceCents: { type: Number, default: 0 }
}, { timestamps: true });
export default mongoose.model('Account', AccountSchema);
