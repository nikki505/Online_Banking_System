import mongoose from 'mongoose';
const AuditEventSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true },
  action: { type: String, required: true },
  meta: { type: Object },
  at: { type: Date, default: Date.now }
});
export default mongoose.model('AuditEvent', AuditEventSchema);
