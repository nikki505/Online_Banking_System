import mongoose from 'mongoose';
const ScheduledTransferSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  fromAccount: { type: String, required: true },
  toAccount: { type: String, required: true },
  amountCents: { type: Number, required: true },
  memo: { type: String },
  executeAt: { type: Date, required: true },
  executed: { type: Boolean, default: false },
  executedAt: { type: Date }
}, { timestamps: true });
export default mongoose.model('ScheduledTransfer', ScheduledTransferSchema);
