import mongoose from 'mongoose';
const TransactionSchema = new mongoose.Schema({
  fromAccount: { type: String, index: true },
  toAccount: { type: String, index: true },
  amountCents: { type: Number, required: true },
  status: { type: String, enum: ['completed','scheduled','canceled','failed'], default: 'completed' },
  scheduledFor: { type: Date },
  memo: { type: String },
  category: { type: String, enum: ['Food','Bills','Shopping','Transport','Entertainment','Other'], default: 'Other' },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });
export default mongoose.model('Transaction', TransactionSchema);
