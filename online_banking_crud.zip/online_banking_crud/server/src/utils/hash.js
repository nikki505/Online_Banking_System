import argon2 from 'argon2';
export const hash = (plain) => argon2.hash(plain);
export const verify = (hashStr, plain) => argon2.verify(hashStr, plain);
