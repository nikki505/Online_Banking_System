import jwt from 'jsonwebtoken';
import { config } from '../config.js';
export const signAccess = (payload) => jwt.sign(payload, config.accessSecret, { expiresIn: config.accessTtlSec });
export const signRefresh = (payload) => jwt.sign(payload, config.refreshSecret, { expiresIn: config.refreshTtlSec });
export const verifyAccess = (token) => jwt.verify(token, config.accessSecret);
export const verifyRefresh = (token) => jwt.verify(token, config.refreshSecret);
