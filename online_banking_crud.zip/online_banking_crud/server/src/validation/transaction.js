import { z } from 'zod';
export const TxCreateSchema = z.object({
  fromAccount: z.string().min(6),
  toAccount: z.string().min(6),
  amountCents: z.number().int().positive(),
  memo: z.string().max(140).optional(),
  scheduledFor: z.string().datetime().optional()
});
export const TxPatchSchema = z.object({
  memo: z.string().max(140).optional(),
  status: z.enum(['completed','scheduled','canceled','failed']).optional(),
  scheduledFor: z.string().datetime().nullable().optional()
});
