export const ok = (res, data, code=200) => res.status(code).json(data);
export const fail = (res, err, code=400) => res.status(code).json({ error: err });
