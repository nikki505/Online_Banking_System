import { z } from 'zod';
export const OwnTransferSchema = z.object({
  fromAccount: z.string().min(4),
  toAccount: z.string().min(4),
  amountCents: z.number().int().positive(),
  memo: z.string().max(140).optional()
}).refine(d => d.fromAccount !== d.toAccount, { message: 'Accounts must differ', path: ['toAccount'] });

export const UserTransferSchema = z.object({
  fromAccount: z.string().min(4),
  toAccount: z.string().min(4),
  amountCents: z.number().int().positive(),
  memo: z.string().max(140).optional(),
  scheduleAt: z.string().datetime().optional()
});
