import { z } from 'zod';
export const RegisterSchema = z.object({ email: z.string().email(), password: z.string().min(8) });
export const LoginSchema = z.object({ email: z.string().email(), password: z.string().min(1) });
export const UserPatchSchema = z.object({ role: z.enum(['user','admin']).optional() });
