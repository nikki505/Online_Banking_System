import { z } from 'zod';
export const PayeeCreateSchema = z.object({
  name: z.string().min(2),
  accountNumber: z.string().min(6),
  bank: z.string().optional(),
  nickname: z.string().optional()
});
export const PayeePatchSchema = z.object({
  name: z.string().min(2).optional(),
  accountNumber: z.string().min(6).optional(),
  bank: z.string().optional(),
  nickname: z.string().optional()
});
