import { z } from 'zod';
export const AccountCreateSchema = z.object({
  type: z.enum(['checking','savings']),
  number: z.string().min(6),
  balanceCents: z.number().int().nonnegative().default(0)
});
export const AccountPatchSchema = z.object({
  type: z.enum(['checking','savings']).optional(),
  balanceCents: z.number().int().nonnegative().optional()
});
